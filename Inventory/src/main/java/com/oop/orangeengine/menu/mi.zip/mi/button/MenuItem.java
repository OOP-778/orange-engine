package org.brian.core.mi.button;

import org.bukkit.inventory.ItemStack;

public class MenuItem extends AMenuButton {

    public MenuItem(ItemStack itemStack, int slot) {
        super(itemStack, slot, null);
    }

}
